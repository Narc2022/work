
$(document).ready(function () {
    $(function () {
        var x, y;
        $('#dnd_draggable').draggable({ helper: 'clone' });
        $('#dnd-image').droppable({
            drop: function (event, ui) {
                $('#dnd_draggable')
                    .addClass('dnd-hide')
                $("#dndoverlay")
                    .addClass('overlay-show')
                $(".popup")
                    .addClass('overlay2-show')
                x = ui.position.left;
                y = ui.position.top;
                console.log(x);
                console.log(y);
            }
        });
        var smileID = 600;
        var angryID = 700;
        var starID = 800;
        var inputID = 900;

        $(".btn1").click(function () {
            var smile = '<div class="draggable" id="' + `${smileID}` + '"><img src="./smile.svg" id="" alt="" srcset="" style="background-color: white;"></div>';
            $('#dnd_draggable')
                .removeClass('dnd-hide')
            $("#dndoverlay")
                .removeClass('overlay-show')
            $(".popup")
                .removeClass('overlay2-show')
            $(".dnd-image").append(smile);
            loctation(smileID, x, y);
            smileID++;
        });
        $(".btn2").click(function () {
            var angry = '<div class="draggable" id="' + `${angryID}` + '"><img src="./frown.svg" id="" alt="" srcset="" style="background-color: white;"></div>';
            $('#dnd_draggable')
                .removeClass('dnd-hide')
            $("#dndoverlay")
                .removeClass('overlay-show')
            $(".popup")
                .removeClass('overlay2-show')
            $(".dnd-image").append(angry);
            loctation(angryID, x, y);
            angryID++;
        });

        $(".btn3").click(function () {
            var star = '<div class="draggable" id="' + `${starID}` + '"><img src="./star.svg" id="" alt="" srcset="" style="background-color: white;"></div>';
            $('#dnd_draggable')
                .removeClass('dnd-hide')
            $("#dndoverlay")
                .removeClass('overlay-show')
            $(".popup")
                .removeClass('overlay2-show')
            $(".dnd-image").append(star)
            loctation(starID, x, y);
            starID++;
        });
        $(".btn4").click(function () {
            var input = '<div class="draggable" id="' + `${inputID}` + '"><input type="text" style="background-color: white;"></div>'
            $('#dnd_draggable')
                .removeClass('dnd-hide')
            $("#dndoverlay")
                .removeClass('overlay-show')
            $(".popup")
                .removeClass('overlay2-show')
            $(".dnd-image").append(input)
            loctation(inputID, x, y);
            inputID++;
        });
        $(".btn5").click(function () {
            $('#dnd_draggable')
                .removeClass('dnd-hide')
            $("#dndoverlay")
                .removeClass('overlay-show')
            $(".popup")
                .removeClass('overlay2-show')
            $(".draggable").remove().empty();
        });

        function loctation(idvalue, xvalue, yvalue) {
            $(`#${idvalue}`).css("position", "absolute");
            $(`#${idvalue}`).css("left", xvalue - 490);
            $(`#${idvalue}`).css("top", yvalue - 80);
        }
        $('.draggable').draggable();

    });
});