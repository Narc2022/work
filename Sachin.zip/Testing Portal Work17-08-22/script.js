function openNav() {
    var contWidth = "85%"
    document.getElementById("mySidenav").style.width = "15%";
    document.getElementById("content").style.width = contWidth;
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("content").style.width = "100%";
}

$("#open").click(function () {
    $('#open').css({ "display": "none" });
    $('#close').css({ "display": "inline-flex" });
});
$("#close").click(function () {
    $('#close').css({ "display": "none" });
    $('#open').css({ "display": "inline-flex" });
});

$('#dnd_draggable')
    .removeClass('dnd-hide')
$("#dndoverlay")
    .addClass('overlay-show')