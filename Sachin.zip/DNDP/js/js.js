$(window).load(function () {
            
    var elementArray = elements.split("|");
    var str ="";
        for (let i = 0; i < elementArray.length; i++) {
       str+=     '<li id="a"><div class="turtle-list-inner"><span></span></div></li>'
        }
        $(".drag").append(str);
})