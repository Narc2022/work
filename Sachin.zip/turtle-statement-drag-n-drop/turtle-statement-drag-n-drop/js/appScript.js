$(window).load(function () {
  var outputArr1 = [];
  var outputArr2 = [];
  var outputArr3 = [];
  var elementArray = elements.split("|");
  var str ="";
      for (let i = 0; i < elementArray.length; i++) {
     str+=     '<li id="a"><div class="turtle-list-inner"><span></span></div></li>'
      }
      $(".drag").append(str);
  var draggablestrArr = draggablestr.split("|");
  var droppableStrArr = droppableStr.split("|");
  var draggablePreCodeArr = draggablePreCode.split("|");
  var statementHeadArr = statementHead.split("|");

  var draggHtml = "";
  var droppHtml = "";
  var compDrop = 0;
  var backPunchDataArr = [];
  var backPunchDataArr1 = [];
  var firstPart = "";
  var secondPart = "";
  var firstDrop = "";
  var secondDrop = "";

  if (backPunch) {
    backPunchDataArr = backPunchData.split(":");
    if (backPunchDataArr[0] == "") {
      backPunchDataArr1 = backPunchDataArr[1].split(",");
      secondPart = backPunchDataArr1;
      secondDrop = listCreations(secondPart);
    }
    if (backPunchDataArr[1] == "") {
      backPunchDataArr1 = backPunchDataArr[0].split(",");
      firstPart = backPunchDataArr1;
      firstDrop = listCreations(firstPart);
      console.log(firstDrop);
    }
    if (backPunchDataArr[0] != "" && backPunchDataArr[1] != "") {
      firstPart = backPunchDataArr[0].split(",");
      secondPart = backPunchDataArr[1].split(",");
      backPunchDataArr1 = firstPart.concat(secondPart);
      firstDrop = listCreations(firstPart);
      secondDrop = listCreations(secondPart);
    }
  }
  for (var i = 0; i < draggablestrArr.length; i++) {
    if (!backPunch) {
      draggHtml +=
        '<li id="' +
        draggablePreCodeArr[i] +
        '"><div class="turtle-list-inner"><span>' +
        draggablestrArr[i] +
        "</span></div></li>";
    } else {
      if (!backPunchDataArr1.includes(draggablePreCodeArr[i])) {
        draggHtml +=
          '<li id="' +
          draggablePreCodeArr[i] +
          '"><div class="turtle-list-inner"><span>' +
          draggablestrArr[i] +
          "</span></div></li>";
      }
    }
  }

  for (var j = 0; j < droppableStrArr.length; j++) {
    var myList = "";
    if (j == 0) {
      myList = firstDrop;
    } else {
      myList = secondDrop;
    }
    droppHtml +=
      '<div class="toolblock"> \
        <div class="headlineText"> \
        <div class="cir-container"><div class="cir-inner">0</div></div> <div class="heatTextCenter">' +
      droppableStrArr[j] +
      '</div> \
        </div> \
        <div class="droppableArea sortable droppable" id="dropArea_' +
      j +
      '" data-section="1" data-info="' +
      j +
      '">' +
      myList +
      "</div> \
        </div>";
  }

  var draggFinalhtml =
    '<div class="toolblock statement_container"><h3>' +
    statementHead +
    '</h3><div class="draggableArea draggable droppable" id="dragArea " data-section="1 ">' +
    draggHtml +
    "</div></div>";
  //console.log(droppHtml)

  $(".toolwarper").html(
    draggFinalhtml +
      "<div class='droppableArea_Container'>" +
      droppHtml +
      "</div>"
  );

  $(".sortable")
    .sortable({
      update: function () {
        datacalculations($(this).attr("id"));
      },
    })
    .disableSelection();

  $(".draggable li").draggable({
    revert: true,
  });

  $(".droppable").droppable({
    drop: function (e, ui) {
      var el = $(ui.draggable).removeAttr("style").clone().appendTo($(this));

      if ($(ui.draggable).parent().find("li").size() == 1)
        $(ui.draggable).parent().addClass("empty");
      else $(ui.draggable).parent().removeClass("empty");

      $(ui.draggable).remove();

      if ($(this).find("li").size() == 1) $(this).addClass("empty");
      else $(this).removeClass("empty");

      if ($(this).is(".sortable")) {
        $(this).sortable("refresh");
        $(this).sortable("refreshPositions");
      } else {
        $(el).draggable({
          revert: true,
        });
      }

      $(this).find(".ui-draggable-dragging").addClass("selected");
      if (!$(".ui-draggable-dragging").hasClass("selected")) {
        // $(this).find('.ui-draggable-dragging').addClass("selected");
        //$('.ui-draggable-dragging').removeClass("selected");
        // console.log("added");
      } else {
        //  $('.ui-draggable-dragging').removeClass("selected");
        //$(".droppableArea ").find('.ui-draggable-dragging').addClass("selected");
        // console.log("not")
      }

      equaleHeight();
      datacalculations();
      //emptyDropable();
    },
    accept: function (draggable) {
      return (
        $(draggable).parent().data("section") == $(this).data("section") &&
        !$(draggable).parent().is($(this))
      );
    },
  });

  function datacalculations(droptedNow) {
    outputArr1 = [];
    outputArr2 = [];
    outputArr3 = [];
    $("#dropArea_0 li").each(function (index, value) {
      outputArr1[index] = $(this).attr("id");
    });
    $("#dropArea_1 li").each(function (index, value) {
      outputArr2[index] = $(this).attr("id");
    });
    $("#dragArea li").each(function (index, value) {
      outputArr3[index] = $(this).attr("id");
    });

    //console.log(outputArr1 + ":" + outputArr2);
    var finalData = outputArr1 + ":" + outputArr2;

    // if (outputArr3 == "") {
    //   compDrop = 1;
    // }
    if (outputArr1.length + outputArr2.length == draggablestrArr.length) {
      compDrop = 1;
    } else {
      compDrop = 0;
    }
    console.log(outputArr3);
    outputdata(finalData, compDrop);
    emptyDropable();
  }
  if (backPunch) {
    datacalculations();
  }
  function equaleHeight() {
    $(".droppableArea").height("auto");
    var nwHght = 0;
    $(".droppableArea").each(function () {
      if (nwHght < $(this).height()) {
        nwHght = $(this).height();
      }
    });
    // console.log(nwHght);
    $(".droppableArea").height(nwHght);
  }

  function emptyDropable() {
    $(".droppableArea").each(function (index, value) {
      var datainfo = $(".droppableArea").attr("data-info");
      var currentdraggableLen = $(this).find(".ui-draggable").length < 1;
      var draggableLen = $(".draggableArea").find(".ui-draggable").length < 1;
      var counter = $(this).find(".ui-draggable").length;
      $(this).prev().find(".cir-inner").text(counter);
      //console.log(counter);
      if (currentdraggableLen == true && draggableLen == true) {
        $(this).addClass("no-data-active");
        $(this).html(
          "<div class='no-data'>!Ohh your have not drop in this box </div>"
        );
      } else {
        //console.log($(this));
        $(this).find(".no-data").remove();
        $(this).removeClass("no-data-active");
      }
    });
  }
  function listCreations(arr) {
    var statement = "";
    for (let index = 0; index < arr.length; index++) {
      statement +=
        '<li id="' +
        arr[index] +
        '" class="ui-draggable ui-draggable-dragging selected"><div class="turtle-list-inner"><span>' +
        draggablestrArr[draggablePreCodeArr.indexOf(arr[index])] +
        "</span></div></li>";
    }
    return statement;
  }
});
