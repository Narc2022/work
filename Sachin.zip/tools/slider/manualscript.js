$(function(){
    $('#slider1').slider();
    $('#slider2').slider();
    $('#slider3').slider();
    $('#slider4').slider();
})
$(function(){
    
})
$(function(){
    
})
$(function(){
    
})
