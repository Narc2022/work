var outputArrb = [];
var image1 = './img/01card_of_tech.svg';
var image2 = './img/01card_of_tech.svg';
var image3 = './img/01card_of_tech.svg';
var image4 = './img/01card_of_tech.svg';
var image5 = './img/01card_of_tech.svg';
var image6 = './img/01card_of_tech.svg';
var image7 = './img/01card_of_tech.svg';
var image8 = './img/01card_of_tech.svg';

var getSliderVal;
$(document).on('ready', function () {
    $(".main-slider").slick({
      lazyLoad: 'ondemand',
      infinite: false,
      valueOfdots: true,
      centerMode: true,
      slidesToShow: 1,
      slidesToScroll: 1
    });
    $(".slick-next ").attr("id", "BN1");
    $(".slick-prev ").attr("id", "BP1");
    function optimizer(class1, class2) {
      if ($(class1).hasClass('active')) {
        $(class1).removeClass('active')
      } else {
        $(class1).addClass('active')
        $(class2).removeClass('active')
      }
    }

    function arrow_click(classslb1, classslb2) {
      $(classslb2).removeClass('active');
      $(classslb1).removeClass('active');
    }

    var btn;
    function pushval( btn , val){
        if($(btn).hasClass('active')){
            var sliderVal = $('.slick-current').attr('data-slick-index');
            getSliderVal = parseInt(sliderVal)+1;
            var finalVal = getSliderVal + ":" + val;
            outputArrb.push(finalVal);
            outputdata(outputArrb);
        }
    }

    function outputdata(data1) {
        $("#backpunch").val(data1);
    }

    //like
    $('.cb-value').click(function () {
      optimizer(".toggle-btn", ".toggle-btn-dislike");
    });

    //Dislike
    $('.db-value').click(function () {
      optimizer(".toggle-btn-dislike", ".toggle-btn");
    });

    $('.slick-arrow').click(function () {
      arrow_click('.toggle-btn', '.toggle-btn-dislike')
    });

    $('.toggle-btn').click(function(){
        pushval( '.toggle-btn' , 1);
    });
    
    $('.toggle-btn-dislike').click(function(){
        pushval( '.toggle-btn-dislike' , 0);
    });

  });